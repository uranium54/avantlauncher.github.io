(function(){
 const bar=document.createElement('div'); bar.id='page-progress'; document.body.prepend(bar);
 let value=7, loaded=false;
 function set(v){ value=Math.max(value,Math.min(v,100)); bar.style.width=value+'%'; bar.style.opacity='1'; }
 set(8);
 const timer=setInterval(()=>{ if(loaded){clearInterval(timer);return;} const r=performance.getEntriesByType('resource'); const done=r.filter(x=>x.responseEnd>0).length; const total=Math.max(r.length,1); const target=Math.min(90,8+(done/total)*70); set(Math.max(target,8)); },100);
 function finish(){ loaded=true; set(100); setTimeout(()=>{bar.style.opacity='0';},180); setTimeout(()=>{bar.remove();},520); }
 if(document.readyState==='complete') finish(); else window.addEventListener('load',finish,{once:true});
 document.querySelectorAll('a[href]').forEach(a=>a.addEventListener('click',function(e){
   const href=this.getAttribute('href');
   if(!href||href.startsWith('#')||href.startsWith('http')||this.target==='_blank') return;
   e.preventDefault(); set(18); setTimeout(()=>set(35),90); setTimeout(()=>location.href=href,120);
 }));
})();
