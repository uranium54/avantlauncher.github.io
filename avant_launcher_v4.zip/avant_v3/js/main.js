const nav=document.querySelector('.nav');
addEventListener('scroll',()=>nav?.classList.toggle('on',scrollY>25));
const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('show');io.unobserve(e.target)}}),{threshold:.1});
document.querySelectorAll('.reveal').forEach(x=>io.observe(x));
document.querySelectorAll('.faqitem').forEach(x=>x.addEventListener('click',()=>x.classList.toggle('open')));
async function loadMods(){
 const names=['sodium','iris','lithium','ferrite-core'];
 const cards=[...document.querySelectorAll('[data-mod]')];
 await Promise.all(cards.map(async(card,i)=>{try{const r=await fetch('https://api.modrinth.com/v2/project/'+names[i]);const d=await r.json();card.querySelector('img').src=d.icon_url;card.querySelector('[data-name]').textContent=d.title;card.querySelector('[data-desc]').textContent=d.description||'Minecraft mod';}catch(e){card.querySelector('img').alt='Mod logo';}}));
}
if(document.querySelector('[data-mod]'))loadMods();
